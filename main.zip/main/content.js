chrome.storage.sync.get("blockedSites", function(data) {
  var blockedSites = data.blockedSites;

  for (var i = 0; i < blockedSites.length; i++) {
    if (window.location.href.includes(blockedSites[i])) {
      document.documentElement.innerHTML = "";
    }
  }
});

chrome.storage.sync.get("blockedSites", function (data) {
  var blockedSites = data.blockedSites || [];

  // Get the URL for Task.html within the extension
  const taskPageUrl = chrome.runtime.getURL('Task.html');

  // If the current page is not Task.html, proceed with the blocking check
  if (window.location.href !== taskPageUrl) {
    for (var i = 0; i < blockedSites.length; i++) {
      if (window.location.href.includes(blockedSites[i])) {
        // Block the site by clearing the page content
        document.documentElement.innerHTML = "";

        // Redirect to Task.html after blocking
        window.location.href = taskPageUrl;
        break;
      }
    }
  }
});
